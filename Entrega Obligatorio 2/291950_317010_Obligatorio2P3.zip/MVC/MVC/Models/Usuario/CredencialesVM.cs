﻿namespace MVC.Models.Usuario
{
    public class CredencialesVM
    {
        public string Email { get; set; }
        public string Contrasena { get; set; }
    }
}
