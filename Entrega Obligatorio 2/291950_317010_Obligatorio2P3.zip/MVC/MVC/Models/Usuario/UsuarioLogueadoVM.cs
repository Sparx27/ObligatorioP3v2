﻿namespace MVC.Models.Usuario
{
    public class UsuarioLogueadoVM
    {
        public int Id { get; set; }
        public string Rol { get; set; }
        public string Token { get; set; }
    }
}
