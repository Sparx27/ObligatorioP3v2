﻿namespace MVC.Models.Disciplina
{
    public class DisciplinaUpdateVM
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public int AnioIntegracion { get; set; }
    }
}
