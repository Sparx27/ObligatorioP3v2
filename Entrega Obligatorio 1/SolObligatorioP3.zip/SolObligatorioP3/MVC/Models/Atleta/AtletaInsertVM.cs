﻿namespace MVC.Models.Atleta
{
    public class AtletaInsertVM
    {
        public string Nombre { get; set; }
        public int Sexo { get; set; }
    }
}
