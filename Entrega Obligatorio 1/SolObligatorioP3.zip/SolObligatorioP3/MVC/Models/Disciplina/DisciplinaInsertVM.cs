﻿namespace MVC.Models.Disciplina
{
    public class DisciplinaInsertVM
    {
        public string Nombre { get; set; }
        public int AnioIntegracion { get; set; }
    }
}
