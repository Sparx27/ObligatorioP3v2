﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio.Enums
{
    public enum Rol
    {
        Administrador = 0,
        Digitador = 1
    }
}
