﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compartido.DTOs.Eventos
{
    public class PEAUpdateDTO
    {
        public int AtletaId { get; set; }
        public decimal Puntaje { get; set; }
    }
}
