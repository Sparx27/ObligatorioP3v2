﻿namespace MVC.Models.Pais
{
    public class PaisInsertVM
    {
        public string Nombre { get; set; }
        public int Habitantes { get; set; }
        public string NombreDelegado { get; set; }
        public string TelDelegado { get; set; }
    }
}
