﻿namespace MVC.Models.Usuario
{
    public class UsuarioRolVM
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
